// Check if js is linked
console.log("work work work work work")

// linking button to javascript variable
let bookFlightBtn = document.getElementById("book-flight");

// add event listener to js variable btn to alert when pressed
bookFlightBtn.addEventListener("click", ()=> {
    console.alert("button pressed")
})